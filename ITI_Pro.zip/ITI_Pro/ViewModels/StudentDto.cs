﻿using ITI_Pro.Models;
using System.ComponentModel.DataAnnotations;

namespace ITI_Pro.ViewModels
{
    public class StudentDto
    {
        [Key]

        public int S_ID { get; set; }
        public string S_FName { get; set; }

        public string S_LName { get; set; }
        public string S_Image { get; set; }

        public Gender Gender { get; set; }
        public DateTime DateOfBirth { get; set; }

        public string City { get; set; }
        public string PhoneNum { get; set; }
        public List<string>? Courses { get; set; }
        public List<string>? Lessons { get; set; }
    }


    public class EnrollmentRequest
    {
        public string UserId { get; set; }
        public string CourseId { get; set; }
    }




}
