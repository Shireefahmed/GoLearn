﻿using ITI_Pro.Models;
using System.Text.Json.Serialization;

namespace ITI_Pro.ViewModels
{
    public class LessonDto
    {
        public int L_Id { get; set; }
        public string? L_Description { get; set; }
        public string? L_Title { get; set; }
        public int CourseID { get; set; }

    


    }
}
