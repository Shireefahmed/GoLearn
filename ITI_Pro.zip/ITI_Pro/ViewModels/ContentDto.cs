﻿namespace ITI_Pro.ViewModels
{
    public class ContentDto
    {
        public int Content_Id { get; set; }
        public IFormFile VideoPath { get; set; }
        public IFormFile FilePath { get; set; }
        public string Title { get; set; }
        public string ContentType { get; set; }
        public IFormFile ImagePath { get; set; }
        public string? L_Id { get; set; }

    }
}
