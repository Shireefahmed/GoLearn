﻿using System.ComponentModel.DataAnnotations;

namespace ITI_Pro.ViewModels
{
    public class LoginUserViewModelSec
    {
        
      //  public int ID { get; set; }
        
        [Required]
        public string UserName { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        //public bool RememberMe { get; set; }
    }
}
