﻿namespace ITI_Pro.ViewModels
{
    public class CourseDto
    {
        public int Course_Id { get; set; }
        public string C_Description { get; set; }
        public string C_Title { get; set; }
        public IFormFile? ImageUrl { get; set; }

    }
    public class CourseDtooo
    {
      public  string? userID { get; set; }
        public int Course_Id { get; set; }
        public string C_Description { get; set; }
        public string C_Title { get; set; }
        public IFormFile? ImageUrl { get; set; }

    }
}
