﻿using ITI_Pro.Models;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ITI_Pro.ViewModels
{
    public class RegisterUserViewModelSec
    {
        [Required]

        public string Role { get; set; }

        //   public int ID { get; set; }
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }
        [Required]
        public string UserName { get; set; }


        [Required]
        public string Email { get; set; }

        [DataType(DataType.Password)]
        public string Password { get; set; }

        public IFormFile? I_Image { get; set; }
        public string? City { get; set; }
        //    public string? PhoneNum { get; set; }
        public string? PhoneNumber { get; set; }

        public string? Specialization { get; set; }
     //   public DateTime HiringDate { get; set; }
        public DateTime DateOfBirth { get; set; }
     //  public int? Experience { get; set; }
        public Gender Gender { get; set; }
        [JsonIgnore]
        public List<Course>? courses { get; set; }

        [JsonIgnore]
        public List<Lesson>? lessons { get; set; }






        //[Required]
        //[DataType(DataType.Password)]
        //[Compare("Password")]
        //public string ConfirmPassword { get; set; }



    }
}
