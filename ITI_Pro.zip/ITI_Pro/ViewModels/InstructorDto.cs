﻿using ITI_Pro.Models;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ITI_Pro.ViewModels
{
    public class InstructorDto
    {
        public string id { get; set; }
        public string? I_FName { get; set; }

        public string? I_LName { get; set; }
        public IFormFile? Image { get; set; }
        public string? City { get; set; }
        public string? PhoneNum { get; set; }

        public string? Specialization { get; set; }
   //     public DateTime HiringDate { get; set; }
        public DateTime DateOfBirth { get; set; }
     //   public int Experience { get; set; }
        public Gender Gender { get; set; }
        [JsonIgnore]
        public List<Course>? courses { get; set; }
    }
}
