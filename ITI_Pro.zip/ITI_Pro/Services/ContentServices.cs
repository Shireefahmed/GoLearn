﻿using ITI_Pro.Helpers;
using ITI_Pro.Models;
using ITI_Pro.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace ITI_Pro.Services
{
    public class Contentservices : IServicesBase<Content>
    {
        private readonly ITIPRDbContext Context;

        public Contentservices(ITIPRDbContext context)
        {
            Context = context;
        }
        public async Task Add(Content Model) { }
        
       
        public async Task Delete(int id)
        {
            Context.Contents.Remove(Context.Contents.FirstOrDefault(s => s.Content_Id == id));
            await Context.SaveChangesAsync();
        }


        public async Task<List<Content>> GetAll()
        {
         
          var c=  await Context.Contents.ToListAsync();
            return c;
        }

        public async Task<Content> GetDetails(int id)
        {
            return await Context.Contents.FirstOrDefaultAsync(s => s.Content_Id == id);
        }

        public async Task Update(int id, Content Model)
        {
            Content TK = Context.Contents.FirstOrDefault(s => s.Content_Id == id);
            // student.Id = Model.Id;
            TK.Title = Model.Title;
            TK.FilePath = Model.FilePath;
            TK.ImagePath = Model.ImagePath;
            TK.ContentType = Model.ContentType;




            await Context.SaveChangesAsync();

        }
    }
}
