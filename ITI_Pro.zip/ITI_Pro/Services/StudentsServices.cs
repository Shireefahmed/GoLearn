﻿//using ITI_Pro.Models;
//using Microsoft.EntityFrameworkCore;

//namespace ITI_Pro.Services
//{
//    public class StudentsServices : IServicesBase<Students>
//    {
//        private readonly ITIPRDbContext Context;

//        public StudentsServices(ITIPRDbContext context)
//        {
//            Context = context;
//        }
//        public async Task Add(Students Model)
//        {
//            Context.Students.Add(Model);
//            await Context.SaveChangesAsync();
//            // return Model.Tran_ID;
//        }
//        public async Task Delete(int id)
//        {
//            Context.Students.Remove(Context.Students.FirstOrDefault(s => s.S_ID == id));
//            await Context.SaveChangesAsync();
//        }


//        public async Task<List<Students>> GetAll()
//        {
//            return await Context.Students.ToListAsync();
//        }

//        public async Task<Students> GetDetails(int id)
//        {
//            return await Context.Students.FirstOrDefaultAsync(s => s.S_ID == id);
//        }

//        public async Task Update(int id, Students Model)
//        {
//            Students TK = Context.Students.FirstOrDefault(s => s.S_ID == id);
//            // student.Id = Model.Id;
//            TK.S_FName = Model.S_FName;
//            TK.S_LName = Model.S_LName;
//            TK.S_Image = Model.S_Image;
//            TK.Gender = Model.Gender;
//            TK.City = Model.City;
//            TK.PhoneNumber = Model.PhoneNumber;
       
    


//          await  Context.SaveChangesAsync();

//        }
//    }
//}
