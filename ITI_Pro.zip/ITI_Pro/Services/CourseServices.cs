﻿using ITI_Pro.Models;
using Microsoft.EntityFrameworkCore;

namespace ITI_Pro.Services
{
    public class CourseServices : IServicesBase<Course>
    {
        private readonly ITIPRDbContext Context;

        public CourseServices(ITIPRDbContext context)
        {
            Context = context;
        }
        public async Task Add(Course Model)
        {
            Context.Courses.Add(Model);
            await Context.SaveChangesAsync();
            //   return Model.C_ID;
        }
        public async Task Delete(int id)
        {
           Context.Courses.Remove(Context.Courses.FirstOrDefault(s => s.Course_Id == id));
            await Context.SaveChangesAsync();
        }


        public async Task<List<Course>> GetAll()
        {
            return await Context.Courses.ToListAsync();
        }

        public async Task<Course> GetDetails(int id)
        {
            return await Context.Courses.FirstOrDefaultAsync(s => s.Course_Id == id);
        }

        public async Task Update(int id, Course Model)
        {
            Course TK = Context.Courses.FirstOrDefault(s => s.Course_Id == id);
            // student.Id = Model.Id;
            TK.C_Description = Model.C_Description;
            TK.C_Title = Model.C_Title;

           await Context.SaveChangesAsync();

        }
    }
}
