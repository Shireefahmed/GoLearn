﻿namespace ITI_Pro.Services
{
    public interface IServicesBase<T>
    {
       Task <List<T>> GetAll();
       Task<T> GetDetails(int id);
        Task Add(T Model);

        Task Update(int id, T Model);
        Task Delete(int id);
    }
}
