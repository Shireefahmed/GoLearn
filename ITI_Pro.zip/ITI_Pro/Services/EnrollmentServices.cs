﻿//using ITI_Pro.Models;
//using Microsoft.EntityFrameworkCore;

//namespace ITI_Pro.Services
//{
//    public class EnrollmentServices : IServicesBase<Enrollment>
//    {
//        private readonly ITIPRDbContext Context;

//        public EnrollmentServices(ITIPRDbContext context)
//        {
//            Context = context;
//        }
//        public async Task Add(Enrollment Model)
//        {
//            Context.Enrollments.Add(Model);
//            await Context.SaveChangesAsync();
//            // return Model.Tran_ID;
//        }
//        public async Task Delete(int id)
//        {
//            Context.Enrollments.Remove(Context.Enrollments.FirstOrDefault(s => s.En_Id == id));
//            await Context.SaveChangesAsync();
//        }


//        public async Task<List<Enrollment>> GetAll()
//        {
//            return await Context.Enrollments.ToListAsync();
//        }

//        public async Task<Enrollment> GetDetails(int id)
//        {
//            return await Context.Enrollments.FirstOrDefaultAsync(s => s.En_Id == id);
//        }

//        public async Task Update(int id, Enrollment Model)
//        {
//            Enrollment TK = Context.Enrollments.FirstOrDefault(s => s.En_Id == id);
//            // student.Id = Model.Id;
//            TK.En_Date = Model.En_Date;
      
    


//          await  Context.SaveChangesAsync();

//        }
//    }
//}
