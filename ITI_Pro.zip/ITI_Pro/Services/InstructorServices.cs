﻿//using ITI_Pro.Models;
//using Microsoft.EntityFrameworkCore;

//namespace ITI_Pro.Services
//{
//    public class InstructorServices /*: IServicesBase<Specializations>*/
//    {
//        private readonly ITIPRDbContext Context;

//        public InstructorServices(ITIPRDbContext context)
//        {
//            Context = context;
//        }
//        public async Task Add(Specializations Model)
//        {
//            Context.Instructors.Add(Model);
//            await Context.SaveChangesAsync();
//            // return Model.TK_ID;
//        }
//        public async Task Delete(int id)
//        {
//            //Context.Instructors.Remove(Context.Instructors.FirstOrDefault(s => s.I_ID == id));
//            //await Context.SaveChangesAsync();

//        }


//        public async Task<List<Specializations>> GetAll()
//        {
//            return await Context.Instructors.ToListAsync();
//        }

//        //public async Task<Specializations> GetDetails(int id)
//        //{
//        //    return  await Context.Instructors.FirstOrDefaultAsync(s => s.I_ID == id);
//        //}

//        //public async Task Update(int id, Specializations Model)
//        //{
//        //    Specializations TK = Context.Instructors.FirstOrDefault(s => s.I_ID == id);
//        //    // student.Id = Model.Id;
//        //    TK.I_FName = Model.I_FName;
//        //    TK.I_LName = Model.I_LName;
//        //    TK.I_Image = Model.I_Image;
//        //    TK.City = Model.City;
//        //    TK.PhoneNumber = Model.PhoneNumber;
//        //    TK.Spectialization = Model.Spectialization;


//        //    await Context.SaveChangesAsync();

//        //}



//    }
//}
