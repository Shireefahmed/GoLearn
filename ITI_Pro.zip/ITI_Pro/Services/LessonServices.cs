﻿using ITI_Pro.Models;
using Microsoft.EntityFrameworkCore;

namespace ITI_Pro.Services
{
    public class LessonServices : IServicesBase<Lesson>
    {
        private readonly ITIPRDbContext Context;

        public LessonServices(ITIPRDbContext context)
        {
            Context = context;
        }
        public async Task Add(Lesson Model)
        {
            Context.Lessons.Add(Model);
            await Context.SaveChangesAsync();
            // return Model.Tran_ID;
        }
        public async Task Delete(int id)
        {
            Context.Lessons.Remove(Context.Lessons.FirstOrDefault(s => s.L_Id == id));
            await Context.SaveChangesAsync();
        }


        public async Task<List<Lesson>> GetAll()
        {
            return await Context.Lessons.ToListAsync();
        }

        public async Task<Lesson> GetDetails(int id)
        {
            return await Context.Lessons.FirstOrDefaultAsync(s => s.L_Id == id);
        }

        public async Task Update(int id, Lesson Model)
        {
            Lesson TK = Context.Lessons.FirstOrDefault(s => s.L_Id == id);
            // student.Id = Model.Id;
            TK.L_Title = Model.L_Title;
            TK.L_Description = Model.L_Description;




            await Context.SaveChangesAsync();

        }
    }
}
