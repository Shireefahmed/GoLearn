﻿using Azure.Core;
using ITI_Pro.Helpers;
using ITI_Pro.Models;
using ITI_Pro.Services;
using ITI_Pro.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using Microsoft.AspNetCore.Identity;

namespace ITI_Pro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ITIPRDbContext dbContext;
        private readonly UserManager<ApplicationUser> userManager;

        public IServicesBase<Course> c_Service { get; }

        public CourseController(IServicesBase<Course> _I_service, ITIPRDbContext dbContext ,UserManager<ApplicationUser> userManager)
        {
            c_Service = _I_service;
            this.dbContext = dbContext;
            this.userManager = userManager;
        }
        [HttpGet] //api/employee/id
        public async Task<IActionResult> GetAll()
        {
            var emps = await c_Service.GetAll();
            if (emps != null)
                return Ok(emps);

            return NotFound();
        }
        [HttpGet("{id:int}")] //api/employee/id
        public async Task<IActionResult> Details(int id)
        {
            var Std = await c_Service.GetDetails(id);
            if (Std == null) return NotFound();
            return Ok( Std );
        }

        //[HttpGet("get-courses")] //api/employee/name
        //public IActionResult CoursesByName([FromQuery] string name)

        //{

        //    IQueryable<Course> Std = dbContext.Courses.Where(n => n.C_Title == name);

        //    if (Std == null) return NotFound();
        //    return Ok(Std);
        //}


        //[HttpGet("get-courses-InsName")] //api/employee/name
        //public IActionResult CoursesByInsName([FromQuery] string name)
        //{
        //IQueryable Std = dbContext.Courses?.Where(x => x.Instructor.I_FName.Contains(name));

        //    if (Std == null) return NotFound();
        //    return Ok(Std);
        //}


        //Add
        [HttpPost]
        [HttpPost("Add")]
        public async Task<IActionResult> Add( CourseDtooo Model)
        {

            string uploadImage = DocumentSettings.UploadImages(Model.ImageUrl);
          
            if (ModelState.IsValid)
            {
                Course c = new Course();
             
                c.ImageUrl = $"{Request.Scheme}://{Request.Host}/{uploadImage}";
                c.C_Title = Model.C_Title;
                c.C_Description = Model.C_Description;
                dbContext.Courses.Add(c);


                await dbContext.SaveChangesAsync();

                var s = await userManager.FindByIdAsync(Model.userID);
                if (s == null || s.Role != "Instructor")
                {
                    return NotFound("User not found or not a student.");
                }

                var userCourse = new UserCourses
                {
                    UserId = s.Id,
                    CourseId = c.Course_Id
                };

                dbContext.UserCourses.Add(userCourse);
                await dbContext.SaveChangesAsync();
                return Ok(userCourse);

                //await dbContext.SaveChangesAsync();


                //return Ok(c);
            }
            return BadRequest();


        }
        //Update
        [HttpPut]
        public async Task<IActionResult> Edit(Course Std)
        {
            /* var oldEmp = db.Student.Find(id);
             oldEmp.Id = emp.Id;*/

            if (Std == null) return BadRequest();
            if (ModelState.IsValid)
            {
                await c_Service.Update(Std.Course_Id, Std);

                return NoContent();
                // return CreatedAtAction(nameof(Details), new {id = emp.Id , Message="Employee Added Succsefully"});
            }
            return BadRequest();


        }
        //Delete
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            //var Std = c_Service.GetDetails(id);
            //if (Std == null) return NotFound();
            //await c_Service.Delete(id);
            var s = dbContext.Courses.FirstOrDefault(s => s.Course_Id == id);
            var Std=  dbContext.Courses.Remove(dbContext.Courses.FirstOrDefault(s => s.Course_Id == id));
           
            await dbContext.SaveChangesAsync();
            return Ok(new {Message= $"the Course have been Removed{s.Course_Id} :{s.C_Title} Sucssfully" });
        }

        ////////////////////////////////////////////search//////////////////
        ///
        [HttpGet("getcoursesbyname/{name:alpha}")] //api/employee/name
        public async Task<IActionResult> getcoursesbyname( string name)

        {

            var Std = await dbContext.Courses.Where(n => n.C_Title.Contains(name) || n.C_Title == name || n.C_Title.StartsWith(name) ||
             n.C_Title.EndsWith(name)).ToListAsync();

            if (Std == null) return NotFound();
            return Ok(Std);
        }
    }
}
