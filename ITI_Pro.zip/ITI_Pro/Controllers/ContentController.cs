﻿using ITI_Pro.Helpers;
using ITI_Pro.Models;
using ITI_Pro.Services;
using ITI_Pro.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ITI_Pro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContentController : ControllerBase
    {
        private IServicesBase<Content> contentservice;
        private readonly ITIPRDbContext context;
        public ContentController(IServicesBase<Content> _contentservice,ITIPRDbContext context)
        {
            this.context = context;
            contentservice = _contentservice;
        }
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var emps = await contentservice.GetAll();
            if (emps != null)
                return Ok(emps);
            //new { Emps = emps, Message = "Data Exist" }
            return NotFound();
        }
        
        [HttpGet("GetById/{Id}")] //api/employee/id
        public async Task<IActionResult> GetById(string Id)
        {
            int id = int.Parse(Id);
            var Std =  context.Contents.FirstOrDefault(s => s.LessID == id);
               
            if (Std == null) return NotFound(new { Msg = "Not Found", Status = 404 });
            return Ok(Std );
        }


        [HttpGet("GetByContentId/{Id}")] //api/employee/id
        public async Task<IActionResult> GetByContentId(string Id)
        {
            int id = int.Parse(Id);
            var Std = context.Contents.FirstOrDefault(s => s.Content_Id == id);
         
            if (Std == null) return NotFound(new { Msg = "Not Found", Status = 404 });
            return Ok(Std);
        }

        //[HttpGet("{name:alpha}")] //api/employee/name
        //public IActionResult DetailsByName(string name)
        //{
        //   // var Std = contentservice..FirstOrDefault(e => e.Name == name);
        //    if (Std == null) return NotFound();
        //    return Ok(new { Msg = $"Employee with name = {name} is Found", EmployeeData = Std });
        //}

        //[HttpPost("Add")]
        //public async Task<IActionResult> Add([FromForm] ContentDto model)
        //{
        ////    Ensure model is valid
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    // Initialize file upload paths
        //    string uploadImage = null;
        //    string uploadFiles = null;
        //    string uploadVideo = null;

        //    // Process file uploads if files are provided
        //    if (model.ImagePath != null)
        //    {
        //        uploadImage = DocumentSettings.UploadImages(model.ImagePath);
        //    }
        //    if (model.FilePath != null)
        //    {
        //        uploadFiles = DocumentSettings.UploadFiles(model.FilePath);
        //    }
        //    if (model.VideoPath != null)
        //    {
        //        uploadVideo = DocumentSettings.UploadVideos(model.VideoPath);
        //    }

        //    // Create new Content object
        //    Content content = new Content
        //    {
        //        VideoPath = uploadVideo != null ? $"{Request.Scheme}://{Request.Host}/{uploadVideo}" : null,
        //        ImagePath = uploadImage != null ? $"{Request.Scheme}://{Request.Host}/{uploadImage}" : null,
        //        Title = model.Title,
        //        ContentType = model.ContentType,
        //        FilePath = uploadFiles != null ? $"{Request.Scheme}://{Request.Host}/{uploadFiles}" : null,
        //        LessID = int.Parse(model.L_Id),

        //    };

        //    // Add to context and save changes
        //    await context.Contents.AddAsync(content);
        //    await context.SaveChangesAsync();

        //    // Return success response
        //    return Ok(content);
        //}













        //Add
        [HttpPost("Add")]
        public async Task<IActionResult> Add(ContentDto Model)
        {

            string uploadImage = DocumentSettings.UploadImages(Model.ImagePath);
            string uploadFiles = DocumentSettings.UploadFiles(Model.FilePath);

            string uploadVideo = DocumentSettings.UploadVideos(Model.VideoPath);
            if (ModelState.IsValid)
            {
                Content c = new Content();
                c.VideoPath = $"{Request.Scheme}://{Request.Host}/{uploadVideo}";
                c.ImagePath = $"{Request.Scheme}://{Request.Host}/{uploadImage}";
                //  c.Content_Id = Model.Content_Id;
                c.Title = Model.Title;
                c.ContentType = Model.ContentType;
                c.FilePath = $"{Request.Scheme}://{Request.Host}/{uploadFiles}";
                  int l_id = int.Parse( Model.L_Id);
                c.LessID = l_id;

                await context.Contents.AddAsync(c);


                await context.SaveChangesAsync();


                return Ok(c);
            }
            return BadRequest();


        }
        //Update
        [HttpPut("Edit")]
        public async Task<IActionResult> Edit(ContentDto Model)
        {
            string uploadImage = DocumentSettings.UploadImages(Model.ImagePath);
            string uploadFiles = DocumentSettings.UploadFiles(Model.FilePath);

            string uploadVideo = DocumentSettings.UploadVideos(Model.VideoPath);
            if (ModelState.IsValid)
            {
               // int I = int.Parse(id);

                var c =  context.Contents.FirstOrDefault(s=>s.Content_Id==Model.Content_Id);
                c.VideoPath = $"{Request.Scheme}://{Request.Host}/{uploadVideo}";
                c.ImagePath = $"{Request.Scheme}://{Request.Host}/{uploadImage}";
                //  c.Content_Id = Model.Content_Id;
                c.Title = Model.Title;
                c.ContentType = Model.ContentType;
                c.FilePath = $"{Request.Scheme}://{Request.Host}/{uploadFiles}";
                int l_id = int.Parse(Model.L_Id);
                c.LessID = l_id;

                //  

               
                await context.SaveChangesAsync();


                return Ok(c);
            }
            return BadRequest();



        }

        //Delete
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {

            var Std = await contentservice.GetDetails(id);
            if (Std == null) return NotFound();
            contentservice.Delete(id);

            return Ok(Std);
        }

    }
}
