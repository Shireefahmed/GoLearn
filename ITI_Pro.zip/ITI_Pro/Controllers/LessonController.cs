﻿using ITI_Pro.Models;
using ITI_Pro.Services;
using ITI_Pro.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ITI_Pro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LessonController : ControllerBase
    {
        private readonly ITIPRDbContext dbContext;

        public IServicesBase<Lesson> L_Service { get; }

        public LessonController(IServicesBase<Lesson> _I_service,ITIPRDbContext dbContext)
        {
            L_Service = _I_service;
            this.dbContext = dbContext;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var emps = await L_Service.GetAll();
            if (emps != null)
                return Ok(emps);
            //new { Emps = emps, Message = "Data Exist" }
            return NotFound();
        }
        [HttpGet("{id:int}")] //api/employee/id
        public async Task<IActionResult> Details(int id)
        {
            var Std = await L_Service.GetDetails(id);
            if (Std == null) return NotFound();
            return Ok( Std );
        }




        [HttpGet("LessonsbycoursID/{id:int}")] //api/employee/id
        public async Task<IActionResult> LessonsbycoursID(int id)
        {
            //var Std = await L_Service.GetDetails(id);

            var Std = await dbContext.Lessons.Where(u => u.CourseID==id).ToListAsync();
            if (Std == null) return NotFound();
            return Ok(Std );
        }

        // [HttpGet("{name:alpha}")] //api/employee/name
        //public IActionResult DetailsByName(string name)
        //{
        //    var Std = i_Service.FirstOrDefault(e => e.Name == name);
        //    if (Std == null) return NotFound();
        //    return Ok(new { Msg = $"Employee with name = {name} is Found", EmployeeData = Std });
        //}

        //Add
        [HttpPost("Add")]
        public async Task<IActionResult> Add(LessonDto Std)
        {
            if (Std == null) return BadRequest();
            Lesson lesson = new Lesson();
            lesson.L_Title = Std.L_Title;
            lesson.L_Description = Std.L_Description;   
            lesson.CourseID = Std.CourseID;
            if (ModelState.IsValid)
            {
                await dbContext.Lessons.AddAsync(lesson);
               await dbContext.SaveChangesAsync();

                return Ok(Std);
            }
            return BadRequest();


        }
        //Update
        [HttpPut]
        public async Task<IActionResult> Edit(Lesson Std)
        {
            /* var oldEmp = db.Student.Find(id);
             oldEmp.Id = emp.Id;*/

            if (Std == null) return BadRequest();
            if (ModelState.IsValid)
            {
                await L_Service.Update(Std.L_Id, Std);

                return NoContent();
                // return CreatedAtAction(nameof(Details), new {id = emp.Id , Message="Employee Added Succsefully"});
            }
            return BadRequest();


        }

        //Delete
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var Std = L_Service.GetDetails(id);
            if (Std == null) return NotFound();
            await L_Service.Delete(id);
            return Ok(Std);
        }







    }
}
