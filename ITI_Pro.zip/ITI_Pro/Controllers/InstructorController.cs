﻿using ITI_Pro.Helpers;
using ITI_Pro.Models;
using ITI_Pro.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ITI_Pro.ViewModels;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using System.Numerics;

namespace ITI_Pro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class InstructorController : ControllerBase
    {
        private readonly ITIPRDbContext dbContext;
        private readonly UserManager<ApplicationUser> userManager;
        //public IServicesBase<ApplicationUser> i_Service { get; set; }

        public InstructorController(ITIPRDbContext dbContext, UserManager<ApplicationUser> userManager)
        {
            //i_Service = _I_service;
            this.dbContext = dbContext;
            this.userManager = userManager;
        }


        [HttpPost]
        public async Task<IActionResult> CreateCourseByinst(string id) {
            var std = await userManager.FindByIdAsync(id);
            if (std.Role== "Instructor") {
            
            
            }return NotFound("wrong Id for an instructor ");


        }






        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var users = await userManager.Users.Where(p => p.Role == "Instructor").ToListAsync();
            if (users != null)
                return Ok(users);

            return NotFound();
        }
        [HttpGet("getbyid/{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var Std = await userManager.FindByIdAsync(id);
           
            if (Std == null) return NotFound(new { Msg = "Not Found", Status = 404 });
            return Ok(Std);
        }
        [HttpPut("Edit")]
        //  public async Task<IActionResult> Edit([FromForm]string id,[FromForm] string Instructor)
        public async Task<IActionResult> Edit( string id, [FromForm] InstructorDto instructor)

        {
            // InstructorDto instructor = JsonConvert.DeserializeObject<ApplicationUser>(Instructor);

            /* var oldEmp = db.Student.Find(id);
             oldEmp.Id = emp.Id;*/
            
            string uploadImage = DocumentSettings.UploadImages(instructor.Image);
           
            var std = await userManager.FindByIdAsync(instructor.id);

            if (std == null) return NotFound("their is no instructor with that id");
           
            std.FirstName = instructor.I_FName;
            std.LastName = instructor.I_LName;
            std.PhoneNumber = instructor.PhoneNum;
            std.Gender = instructor.Gender;
            std.City = instructor.City;
            std.I_Image = $"{Request.Scheme}://{Request.Host}/{uploadImage}";
            std.DateOfBirth = instructor.DateOfBirth;
            std.Specialization = instructor.Specialization;



            if (ModelState.IsValid)
            {
                var result = await userManager.UpdateAsync(std);
                if (result.Succeeded)
                    return Ok(std);
                // return CreatedAtAction(nameof(Details), new {id = emp.Id , Message="Employee Added Succsefully"});
            }
            return BadRequest("faild the Request");


        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var std = await userManager.FindByIdAsync(id);
            if (std == null) return NotFound();

            if (std == null) return NotFound();
            if (std.Role == "Instructor")
            {
                await userManager.DeleteAsync(std);
                return Ok(new { message = $"tne Instructor: {std.FirstName} Is  Deleted :)" });
            }
            else {
                await userManager.DeleteAsync(std);
                return Ok(new { message = $" the Student :{std.FirstName} Is Deleted :)" });

            }
            //await userManager.DeleteAsync(std);

            //return Ok(new { message = $"{std.FirstName} Is Deleted :)" });
        }
        [HttpGet("get-courses/{id:guid}")] //api/employee/name
        public IActionResult CoursesByName(int id)

        {

            var Std = dbContext.Courses.Where(n => n.Course_Id == id).Select(p => p.Course_Id).ToList();

            if (Std == null) return NotFound();
            return Ok(Std);
        }

        [HttpGet("getallcoursesforins/{id}")] //api/employee/id
        public async Task<IActionResult> getallcoursesforins(string id)
        {
            // var Std = await i_Service.GetDetails(id);
            //  var Std=  dbContext.Courses.Where(i=>i.I_ID == id).ToList();
            //var Std = dbContext.StudentCourse.Where(i => i.Crs_ID == id).Include(i=>i.Students).ToList();
      //  var u=  await  userManager.FindByNameAsync(username);
            
          //  var  = dbContext.Users.Select(s=>s.UserCourses.Any(a=>a.UserId==id)).ToList();
          var H= await dbContext.Users.FirstOrDefaultAsync(u => u.Id == id);
            var Std =await dbContext.UserCourses.Where(s => s.UserId == H.Id).Include(u => u.Course).ToListAsync();
                //    //var Std = dbContext.StudentCourse.Where(i => i.Crs_ID == id).Include(i=>i.Students).ToList();



            if (Std == null) return NotFound();
            return Ok(Std );
        }

        /////////////////////////////////////////////////////////////////////////////////////

        //[HttpGet("getnstructorsbycity/{city:alpha}")] //api/employee/name
        //public async Task<IActionResult> getnstructorsbycity(string city)

        //{
        //    if (city == null) return BadRequest();
        //    var result = await userManager.GetUsersInRoleAsync("Instructor");
        //    var instcity = result.Where(r => r.City == city).ToList();
        //    if (instcity == null) return NotFound();
        //    //var inscourses = await result.Courses.ToListAsync();


        //    return Ok(instcity);
        //}

        //[HttpGet("getInstructbyNameandCity/")] //api/employee/name
        //public async Task<IActionResult> getInstructbyNameandCity(string? name, string? city)

        //{
        //    var result = await userManager.GetUsersInRoleAsync("Instructor");
        //    if (name != null && city == null)
        //    {
        //        //   var Std = await userManager.Users.Where(s => s.FirstName.Contains(name) || s.LastName.Contains(name) || s.FirstName + " " + s.LastName == name).ToListAsync();
        //        var std = result.Where(s => s.FirstName.ToLower().Contains(name.ToLower()) || s.LastName.ToLower().Contains(name.ToLower()) || s.FirstName.ToLower() + " " + s.LastName.ToLower() == name.ToLower()).ToList();

        //        return Ok(std);
        //    }
        //    else if (city != null && name == null)
        //    {

        //        var std = result.Where(r => r.City.ToLower() == city.ToLower()).ToList();

        //        return Ok(std);
        //    }
        //    else
        //    {
        //        var std = result.Where(s => s.FirstName.ToLower().Contains(name.ToLower()) || s.LastName.ToLower().Contains(name.ToLower()) || s.FirstName.ToLower() + " " + s.LastName.ToLower() == name.ToLower() && s.City.ToLower() == city.ToLower()).ToList();

        //        return Ok(std);
        //    }
        //    #region Comments
        //    // var Std = await userManager.Users.Where(s=>s.FirstName.Contains(name) || s.LastName.Contains(name) || s.FirstName+" "+s.LastName==name).ToListAsync();
        //    //      String.Concat(s.FirstName + " " + s.LastName).Contains(name)


        //    //   var Std = await dbContext.UserCourses.Where(s => s.UserId == result.Id).Include(u => u.Course).ToListAsync();

        //    //  var courses = result.Courses.ToList();

        //    //if (Std == null) return NotFound();

        //    //var inscourses = await result.Courses.ToListAsync();
        //    //var res2 = await result.Courses.Where(r => r.UserId == id).ToListAsync() as ;
        //    //if (Std == null) return NotFound(); 
        //    #endregion
        //    return BadRequest();



        //}







        [HttpGet("getInstructbyNameandCity/")] //api/employee/name
        public async Task<IActionResult> getInstructbyNameandCity(string? name, string? city)

        {
            var result = await userManager.Users.Where(p => p.Role == "Instructor").ToListAsync();

     
            if (name != null && city == null)
            {
                //   var Std = await userManager.Users.Where(s => s.FirstName.Contains(name) || s.LastName.Contains(name) || s.FirstName + " " + s.LastName == name).ToListAsync();
                var std = result.Where(s => s.FirstName.ToLower().Contains(name.ToLower()) || s.LastName.ToLower().Contains(name.ToLower()) || s.FirstName.ToLower() + " " + s.LastName.ToLower() == name.ToLower()).ToList();

                return Ok(std);
            }
            else if (city != null && name == null)
            {

                var std = result.Where(r => r.City.ToLower() == city.ToLower()).ToList();

                return Ok(std);
            }
            else
            {
                var std = result.Where(s => s.FirstName.ToLower().Contains(name.ToLower()) || s.LastName.ToLower().Contains(name.ToLower()) || s.FirstName.ToLower() + " " + s.LastName.ToLower() == name.ToLower() && s.City.ToLower() == city.ToLower()).ToList();

                return Ok(std);
            }
            #region Comments
            // var Std = await userManager.Users.Where(s=>s.FirstName.Contains(name) || s.LastName.Contains(name) || s.FirstName+" "+s.LastName==name).ToListAsync();
            //      String.Concat(s.FirstName + " " + s.LastName).Contains(name)


            //   var Std = await dbContext.UserCourses.Where(s => s.UserId == result.Id).Include(u => u.Course).ToListAsync();

            //  var courses = result.Courses.ToList();

            //if (Std == null) return NotFound();

            //var inscourses = await result.Courses.ToListAsync();
            //var res2 = await result.Courses.Where(r => r.UserId == id).ToListAsync() as ;
            //if (Std == null) return NotFound(); 
            #endregion
            return BadRequest(name);

        }


        //[HttpGet("get-content/{id}")] //api/employee/name
        //public async Task<IActionResult> ContentById(int id)

        //{
        //    if (!ModelState.IsValid) return BadRequest();
        //    var result = await dbContext.Lessons.Where(i => i.L_Id == id).Include(i => i.Content).ToListAsync();
        //    return Ok(result);
        //}

        //[HttpGet("get-courses/{id}")]
        //public IActionResult CoursesByID(int id)

        //{

        //    var Std = dbContext.Courses.Where(n => n.Course_Id == id).Select(p => p.Course_Id).ToList();

        //    if (Std == null) return NotFound();
        //    return Ok(Std);
        //}



        //[HttpGet("get-courses-statistics/{id}")] //api/employee/name
        //public async Task<IActionResult> CoursesCountStudent(int id)
        //{
        //    if (!ModelState.IsValid) return BadRequest();
        //    var get = await dbContext.Courses.Where(i => i.Course_Id == id).Select(p => p.UserCourses.Count).FirstOrDefaultAsync();
        //    if (get == null) return NotFound();
        //    return Ok(get);
        //}

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    }
    }















//    [Route("api/[controller]")]
//    [ApiController]

//    public class InstructorController : ControllerBase
//    {
//        private readonly ITIPRDbContext dbContext;
//        private readonly UserManager<ApplicationUser> userManager;

//        public IServicesBase<ApplicationUser> i_Service { get; }

//        public InstructorController(IServicesBase<ApplicationUser> _I_service, ITIPRDbContext dbContext, UserManager<ApplicationUser> userManager)
//        {
//            i_Service = _I_service;
//            this.dbContext = dbContext;
//            this.userManager = userManager;
//        }

//        // [Authorize]
//        [HttpGet]
//        public async Task<IActionResult> GetAll()
//        {
//            var emps = await i_Service.GetAll();
//            if (emps != null)
//                return Ok(emps);
//            //, Message = "Data Exist" 

//            return NotFound();
//        }
//        [HttpGet("{id:int}")] //api/employee/id
//        public async Task<IActionResult> Details(int id)
//        {
//            var Std = await i_Service.GetDetails(id);
//            if (Std == null) return NotFound();
//            return Ok(new { Msg = $"Employee with Id = {id} is Found", InstructorData = Std });
//        }
//[HttpGet("getallcoursesforins/{id:int}")] //api/employee/id
//public async Task<IActionResult> getallcoursesforins(int id)
//{
//    // var Std = await i_Service.GetDetails(id);
//    //  var Std=  dbContext.Courses.Where(i=>i.I_ID == id).ToList();
//    //var Std = dbContext.StudentCourse.Where(i => i.Crs_ID == id).Include(i=>i.Students).ToList();
//    var Std = dbContext.Where(i => i.Std_ID == id).Include(i => i.Course).ToList();

//    if (Std == null) return NotFound();
//    return Ok(new { Msg = $"Employee with Id = {id} is Found", InstructorData = Std });
//}
// getCourses(name : string)
// const heades = httpReqeust
// headers = ('query' , name)
// return this.http.get(url/get-coursers) , {heades}


// Search Courses By Instructor Name
//[HttpGet("get-courses")] //api/employee/name
//public IActionResult CoursesByCrsName( string name)

//{
//    //IQueryable<Course> Std = dbContext.Courses.Where(n => n.C_Title == name);   
//    //IQueryable Std = dbContext.Where(n => n.I_FName == name).Include(p => p.courses);
//    //var Std = dbContext.Instructors.Where(i => i.I_FName == name).Include(p => p.courses).ToList();
//    //IQueryable Std = dbContext.Courses?.Where(x => x.Instructor.I_FName.Contains(name));
//    //         var Std = dbContext.Instructors
//    // .Where(i => i.I_FName == name) // Filtering by the instructor's first name
//    // .Join(dbContext.Courses, // Performing the join
//    //       i => i.I_ID,     // Instructor's ID (foreign key in Course)
//    //       c => c.I_ID,     // Course's foreign key
//    //       (i, c) => new    // Select the fields you need
//    //       {

//    //           i.I_FName,
//    //           i.I_Image,
//    //           i.I_LName,
//    //           c.Course_Id,
//    //           c.C_Description,
//    //           c.C_Title,

//    //       })
//    //.OrderBy(c=>c.Course_Id)// Order by Instructor ID
//    // .ToList();
//    //var Std = i_Service.FirstOrDefault(e => e.Name == name);
//    if (Std == null) return NotFound();
//    return Ok(Std);
//}
//Search For Course By Title

//[HttpGet("get-coursess")] //api/employee/name
//public IActionResult CoursesByInsName( string name)

//{

//    IQueryable Std = dbContext.Instructors.Where(n => n.I_FName == name).Include(p => p.courses);
//    //var Std = dbContext.Instructors.Where(i => i.I_FName == name).Include(p => p.courses).ToList();
//    if (Std == null) return NotFound();
//    return Ok(Std);
//}
//Add
//[HttpPost]
//[Consumes("multipart/form-data")]
//public async Task<IActionResult> Add(InstructorDto Std)
//{
//    if (Std == null) return BadRequest();
//    if (ModelState.IsValid)
//    {
//        var iimage = DocumentSettings.UploadImages(Std.Image);
//        var user = new ApplicationUser
//        {

//            UserName = Std.I_FName + Std.I_LName,
//            FirstName = Std.I_FName,
//            LastName = Std.I_LName,
//            Gender = Std.Gender,
//            City = Std.City,
//            PhoneNumber = Std.PhoneNum,
//            I_Image = iimage,
//            DateOfBirth = Std.DateOfBirth,
//            Specialization = Std.Specialization

//        };
//        await userManager.CreateAsync();
//        //return Created($"api/Student/{Std.Id}", Std);
//        //return CreatedAtAction(nameof(Details), new { id = Std.I_ID }, "Added Successfully !!!");
//        return Ok("Created Successfully");
//    }
//    return BadRequest();


//}
//Update
//        [HttpPut]
//        public async Task<IActionResult> Edit(InstructorDto Std)
//        {
//            /* var oldEmp = db.Student.Find(id);
//             oldEmp.Id = emp.Id;*/

//            if (Std == null) return BadRequest();
//            if (ModelState.IsValid)
//            {
//                var uploadimage = DocumentSettings.UploadImages(Std.Image);
//                ApplicationUser user = new ApplicationUser()
//                {
//                    UserName = Std.I_FName + Std.I_LName,
//                    FirstName = Std.I_FName,
//                    LastName = Std.I_LName,
//                    Gender = Std.Gender,
//                    City = Std.City,
//                    PhoneNumber = Std.PhoneNum,
//                    I_Image = uploadimage,
//                    DateOfBirth = Std.DateOfBirth,
//                    Specialization = Std.Specialization

//                };

//                //await i_Service.Update(Std.I_ID, Std);
//                await userManager.UpdateAsync(user);
//                return NoContent();
//                // return CreatedAtAction(nameof(Details), new {id = emp.Id , Message="Employee Added Succsefully"});
//            }
//            return BadRequest();


//        }

//        //Delete
//        [HttpDelete("{id:int}")]
//        public async Task<IActionResult> Delete(int id)
//        {
//            var Std = i_Service.GetDetails(id);
//            if (Std == null) return NotFound();
//            await i_Service.Delete(id);
//            return Ok("Deleted");
//        }





//    }
//}
