﻿using ITI_Pro.Models;
using ITI_Pro.Services;
using ITI_Pro.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ITI_Pro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly ITIPRDbContext dbContext;
        //private readonly IServicesBase<UserManager<ApplicationUser>> services;

        public StudentsController(UserManager<ApplicationUser> userManager, ITIPRDbContext dbContext)
        {

            this.userManager = userManager;
            this.dbContext = dbContext;
            //this.services = services;
        }
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {

            //var emps = await services.GetAll();
            var users = await userManager.Users.Where(p => p.Role == "Student").ToListAsync();
            if (users != null)
                return Ok(users);
            // new { Emps = emps, Message = "Data Exist" }
            return NotFound();
        }
        [HttpGet("getbyid/{id}")] //api/employee/id
        public async Task<IActionResult> GetById(string id)
        {

            var Std = await userManager.FindByIdAsync(id);
            if (Std == null) return NotFound(new { Msg = "Not Found", Status = 404 });
            //return Ok(new { Msg = $"Employee with Id = {id} is Found", EmployeeData = Std });
            return Ok(Std);
        }
        // 
        //[HttpGet("{name:alpha}")] //api/employee/name
        //public IActionResult DetailsByName(string name)
        //{
        //    //var Std = stdservice.FirstOrDefault(e => e.Name == name);
        //    var 
        //    if (Std == null) return NotFound();
        //    return Ok(new { Msg = $"Employee with name = {name} is Found", EmployeeData = Std });
        //}



        //Update
        [HttpPut("Edit/{id}")]
        public async Task<IActionResult> Edit(string id, StudentDto studentDto)
        {
            /* var oldEmp = db.Student.Find(id);
             oldEmp.Id = emp.Id;*/

            var std = await userManager.FindByIdAsync(id);
            if (std == null) return NotFound();
            std.FirstName = studentDto.S_FName;
            std.LastName = studentDto.S_LName;
            std.PhoneNumber = studentDto.PhoneNum;
            std.Gender = studentDto.Gender;
            std.City = studentDto.City;
            if (ModelState.IsValid)
            {
                var result = await userManager.UpdateAsync(std);
                if (result.Succeeded)
                    return Ok(std);
                // return CreatedAtAction(nameof(Details), new {id = emp.Id , Message="Employee Added Succsefully"});
            }
            return BadRequest();


        }
        //[HttpGet("GetStatistics{id:int}")]
        //public async Task<ActionResult> GetStatistics()
        //{
        //    var 
        //}
        //Delete
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var std = await userManager.FindByIdAsync(id);
            if (std == null) return NotFound();

            if (std == null) return NotFound();
            await userManager.DeleteAsync(std);

            return Ok(new { message = $"{std.FirstName} Is Deleted :)" });
        }
        [HttpGet("get-courses/{id}")] //api/employee/name
        public IActionResult CoursesByName(int id)

        {

            var Std = dbContext.Courses.Where(n => n.Course_Id == id).Select(p => p.Course_Id).ToList();

            if (Std == null) return NotFound();
            return Ok(Std);
        }


        [HttpPost("StudentENrollMent")]
        public async Task<IActionResult> StudentENrollMent([FromBody] EnrollmentRequest request)
        {
            if (request == null)
            {
                return BadRequest("Invalid request data.");
            }

            int cusId;
            if (!int.TryParse(request.CourseId, out cusId))
            {
                return BadRequest("Invalid Course ID.");
            }

            var s = await userManager.FindByIdAsync(request.UserId);
            if (s == null || s.Role != "Student")
            {
                return NotFound("User not found or not a student.");
            }

            var userCourse = new UserCourses
            {
                UserId = s.Id,
                CourseId = cusId
            };

            dbContext.UserCourses.Add(userCourse);
            await dbContext.SaveChangesAsync();
            return Ok(userCourse);
        }



        //    [HttpPost("StudentENrollMent")]
        //    public async Task<IActionResult> StudentENrollMent(string userid,string courseId) {
        //        int cusId = int.Parse(courseId);
        //        var s =await userManager.FindByIdAsync(userid);
        //        if (s.Role == "Student") {



        //            var userCourse = new UserCourses
        //            {
        //                UserId = s.Id,
        //                CourseId = cusId
        //            };
        //            dbContext.UserCourses.Add(userCourse);
        //            dbContext.SaveChanges();
        //            return Ok(userCourse);
        //        }
      
        //        return NotFound();


        //    }


 



    }

}
//    [Route("api/[controller]")]
//    [ApiController]
//    public class StudentsController : ControllerBase
//    {
//        private readonly IServicesBase<Students> stdservice;
//        private readonly ITIPRDbContext dbContext;

//        public StudentsController(IServicesBase<Students> _stdservice , ITIPRDbContext dbContext)
//        {
//            stdservice = _stdservice;
//            this.dbContext = dbContext;
//        }
//        [HttpGet]
//        public async Task<IActionResult> GetAll()
//        {
//            var emps = await stdservice.GetAll();
//            if (emps != null)
//                return Ok(emps);
//           // new { Emps = emps, Message = "Data Exist" }
//            return NotFound();
//        }
//        [HttpGet("{id:int}")] //api/employee/id
//        public async Task<IActionResult> GetById(int id)
//        {
//            var Std = await stdservice.GetDetails(id);
//            if (Std == null) return NotFound(new { Msg = "Not Found", Status = 404 });
//            return Ok(new { Msg = $"Employee with Id = {id} is Found", EmployeeData = Std });
//        }
//        // 
//        //[HttpGet("{name:alpha}")] //api/employee/name
//        //public IActionResult DetailsByName(string name)
//        //{
//        //    //var Std = stdservice.FirstOrDefault(e => e.Name == name);
//        //    var 
//        //    if (Std == null) return NotFound();
//        //    return Ok(new { Msg = $"Employee with name = {name} is Found", EmployeeData = Std });
//        //}

//        //Add
//        [HttpPost]
//        public async Task<IActionResult> Add(Students Std)
//        {
//            if (Std == null) return BadRequest();
//            if (ModelState.IsValid)
//            {
//                await stdservice.Add(Std);

//                //return Created($"api/Student/{Std.Id}", Std);
//                return CreatedAtAction(nameof(GetById), new { id = Std.S_ID }, "Added Successfully !!!");
//            }
//            return BadRequest();


//        }
//        //Update
//        [HttpPut]
//        public async Task<IActionResult> Edit(Students Std)
//        {
//            /* var oldEmp = db.Student.Find(id);
//             oldEmp.Id = emp.Id;*/

//            if (Std == null) return BadRequest();
//            if (ModelState.IsValid)
//            {
//                await stdservice.Update(Std.S_ID, Std);
//                return NoContent();
//                // return CreatedAtAction(nameof(Details), new {id = emp.Id , Message="Employee Added Succsefully"});
//            }
//            return BadRequest();


//        }
//        //[HttpGet("GetStatistics{id:int}")]
//        //public async Task<ActionResult> GetStatistics()
//        //{
//        //    var 
//        //}
//        //Delete
//        [HttpDelete("{id}")]
//        public async Task<IActionResult> Delete(int id)
//        {

//            var Std = await stdservice.GetDetails(id);
//            if (Std == null) return NotFound();
//            stdservice.Delete(id);

//            return Ok(Std);
//        }
//        [HttpGet("get-courses/{id:int}")] //api/employee/name
//        public IActionResult CoursesByName( int id)

//        {

//          var Std = dbContext.StudentCourse.Where(n => n.Std_ID == id).Select(p=>p.Course).ToList() ;

//            if (Std == null) return NotFound();
//            return Ok(Std);
//        }

//    }

//}
