﻿using ITI_Pro.Helpers;
using ITI_Pro.Models;
using ITI_Pro.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;


namespace ITI_Pro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly RoleManager<IdentityRole> _roleManager;

        private readonly UserManager<ApplicationUser> usermManger;
        private readonly IConfiguration config;

        public ITIPRDbContext DbContext { get; }

        public AccountController(UserManager<ApplicationUser> UsermManger, IConfiguration config, RoleManager<IdentityRole> roleManager,ITIPRDbContext dbContext)
        {
            _roleManager = roleManager;
            DbContext = dbContext;
            usermManger = UsermManger;
            this.config = config;
        }
        [HttpPost("addrole/{role:alpha}")]
        public async Task<IActionResult> AddRole(string role)
        {
            if (!await _roleManager.RoleExistsAsync(role))
            {
                var result = await _roleManager.CreateAsync(new IdentityRole(role));
                if (result.Succeeded)
                {
                    return Ok(new { meesage = "Role Created" });
                }
                return BadRequest(result.Errors);
            }
            return BadRequest("Role is exist");
        }


        //[HttpPost("assign-role")]
        //public async Task<IActionResult> AssignRole(UserRole modelRole)
        //{
        //    var user = await usermManger.FindByNameAsync(modelRole.UserName);
        //    if (user != null)
        //    {

        //        var res = await usermManger.AddToRoleAsync(user, modelRole.role);
        //        return Ok("Good ROle");
        //    }
        //    return BadRequest();
        //}

        //[HttpPost("assignrole")]
        //public async Task<IActionResult> AssignRole(UserRole model)
        //{
        //    var user = await usermManger.FindByNameAsync(model.UserName);
        //    if (user == null)
        //    {
        //        return BadRequest("User not foud");
        //    }
        //    var result = await usermManger.AddToRoleAsync(user, model.role);
        //    if (result.Succeeded)
        //    {
        //        return Ok(new { message = "Role was created" });
        //    }
        //    return BadRequest(result.Errors);
        //}

        //[HttpPost]
        //[Consumes("multipart/form-data")]
        //public async Task<IActionResult> Add(InstructorDto Std)
        //{
        //    if (Std == null) return BadRequest();
        //    if (ModelState.IsValid)
        //    {
        //        var iimage = DocumentSettings.UploadImages(Std.Image);
        //        var user = new ApplicationUser
        //        {

        //            UserName = Std.I_FName + Std.I_LName,
        //            FirstName = Std.I_FName,
        //            LastName = Std.I_LName,
        //            Gender = Std.Gender,
        //            City = Std.City,
        //            PhoneNumber = Std.PhoneNum,
        //            I_Image = iimage,
        //            DateOfBirth = Std.DateOfBirth,
        //            Specialization = Std.Specialization

        //        };
        //        await userManager.CreateAsync();
        //        //return Created($"api/Student/{Std.Id}", Std);
        //        //return CreatedAtAction(nameof(Details), new { id = Std.I_ID }, "Added Successfully !!!");
        //        return Ok("Created Successfully");
        //    }
        //    return BadRequest();


        //}




        [HttpPost("Register")]
        public async Task<IActionResult> Register(RegisterUserViewModelSec UserRegister )//,string role)
        {
          var uploadimage = DocumentSettings.UploadImages(UserRegister.I_Image);

            if (ModelState.IsValid)
            {
                ApplicationUser AppUser = new ApplicationUser();
                AppUser.FirstName = UserRegister.FirstName;
                AppUser.LastName = UserRegister.LastName;
                AppUser.Role = UserRegister.Role;
                AppUser.UserName = UserRegister.UserName;
                AppUser.Email = UserRegister.Email;
                AppUser.Specialization = UserRegister.Specialization;
                AppUser.I_Image = $"{Request.Scheme}://{Request.Host}/{uploadimage}";
                AppUser.City = UserRegister.City;
                AppUser.DateOfBirth = UserRegister.DateOfBirth;
                AppUser.Gender = UserRegister.Gender;
                //     AppUser.Experience = UserRegister.Experience;
                AppUser.PhoneNumber = UserRegister.PhoneNumber;



                //var Exist = usermManger.AddR(UserRegister.Email);
                //AppUser.PasswordHash = UserRegister.Password;


                IdentityResult result = await usermManger.CreateAsync(AppUser, UserRegister.Password);

                    if (result.Succeeded)
                    {
                     var res = await usermManger.AddToRoleAsync(AppUser, UserRegister.Role);
                    return Ok(res);

                 

                    }
                    foreach (var Error in result.Errors)
                    {
                        ModelState.AddModelError("Password", Error.Description);
                    }
                
              
            }
            return BadRequest(ModelState);
        }
        [HttpPost("Login")]
        public async Task<IActionResult> Login(LoginUserViewModelSec userLogin)
        {
            if (ModelState.IsValid)
            {
                ApplicationUser UserofrmDB = await
                usermManger.FindByNameAsync(userLogin.UserName);
                if (UserofrmDB != null)
                {
                    bool Found = await usermManger.CheckPasswordAsync(UserofrmDB, userLogin.Password);

                    if (Found == true)
                    {

                        List<Claim> UserClaims = new List<Claim>();

                        UserClaims.Add(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));


                        UserClaims.Add(new Claim(ClaimTypes.NameIdentifier, UserofrmDB.Id));
                        UserClaims.Add(new Claim(ClaimTypes.Name, UserofrmDB.UserName));
                        var UserRoles = await usermManger.GetRolesAsync(UserofrmDB);
                        foreach (var roleName in UserRoles)
                        {
                            UserClaims.Add(new Claim(ClaimTypes.Role, roleName));
                        }

                        //config["JWT:SecurityKey"]
                        var secritKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("asdasdasdasdsads!@#@123adsa123125asd465@#@#@#@#@!!!!!"));
                        SigningCredentials signingCred = new SigningCredentials(secritKey, SecurityAlgorithms.HmacSha256);

                        //Desgin Token
                        JwtSecurityToken myToken = new JwtSecurityToken(

                            audience: "https://localhost:4200/",
                            issuer: "https://localhost:44372/",
                            expires: DateTime.Now.AddHours(1),
                            claims: UserClaims,
                            signingCredentials: signingCred

                            );

                        return Ok(new
                        {
                            token = new JwtSecurityTokenHandler().WriteToken(myToken),
                          //  expiration = DateTime.Now.AddHours(1000), //myToken.ValidTo
                                                                      // CreatInfo(UserofrmDB)
                            UserofrmDB.FirstName, UserofrmDB.LastName,
                            UserofrmDB.Role,
                            UserofrmDB.Id,UserofrmDB.UserName,UserofrmDB.City,UserofrmDB.I_Image,UserofrmDB.PhoneNumber,

                        });


                    }
                    ModelState.AddModelError("UserName", "UserNAmeor Password Invalid");

                }
            }
            return BadRequest(ModelState);

        }

        [HttpPost("signout")]
        public IActionResult SignOut([FromBody] string request)
        {
            if (string.IsNullOrEmpty(request))
            {
                return BadRequest("Token is required.");
            }

            // Here you might want to invalidate the token, depending on your approach
            // For example, if you store tokens in a database, you could mark it as invalid.
            // If using JWT, the token itself can't be invalidated, so you'd manage it client-side.

            // Example: Add the token to a blacklist (if implemented)
            //DbContext.TokenBlacklist.Add(new TokenBlacklist { Token = request.Token });
            //DbContext.SaveChanges();

            return Ok("Logged out successfully.");
        }
    








    //public  ActionResult<UserDto>CreatInfo(ApplictionUser user) {
    //    return Ok( new UserDto {
    //    FirstName = user.FirstName,
    //    LastName = user.LastName,
    //    Role = user.Role,
    //    });
    //}


    //[HttpPost("Forget-UserName-Or-Password/{Email}")]
    //public async Task<IActionResult> ForgetUserNameOrPassword(string Email) {
    //    if (string.IsNullOrEmpty(Email)) return BadRequest("invalid Email");
    //    var user=await usermManger.FindByEmailAsync(Email);
    //if(user==null)return Unauthorized("this Email has not been Registered yet");
    //    if (user.EmailConfirmed == true) return BadRequest("ur Email has Confirmed before pls login to ur account");

    //    try
    //    {
    //        if (await SendForgotUsernameOrPasswordEmail(user)) {
    //            return Ok(new JsonResult(new { title = "Forget userName or Password Email Send", Message = "pls check ur Email" }));
    //        }
    //        return BadRequest("Failed to send email. Please contact admin");
    //    }
    //    catch (Exception ex) {
    //        return BadRequest("Failed to send email. Please contact admin");
    //    }

    //}






    //   Helpler Funcc
    //private async Task<bool> SendForgotUsernameOrPasswordEmail(ApplictionUser user)
    //{
    //    var token = await usermManger.GeneratePasswordResetTokenAsync(user);
    //    token = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(token));
    //    var url = $"{config["JWT:ClientUrl"]}/{config["Email:ResetPasswordPath"]}?token={token}&email={user.Email}";

    //    var body = $"<p>Hello: {user.FirstName} {user.LastName}</p>" +
    //       $"<p>Username: {user.UserName}.</p>" +
    //       "<p>In order to reset your password, please click on the following link.</p>" +
    //       $"<p><a href=\"{url}\">Click here</a></p>" +
    //       "<p>Thank you,</p>" +
    //       $"<br>{config["Email:ApplicationName"]}";

    //   // var emailSend = new EmailSendDto(user.Email, "Forgot username or password", body);

    //   // return await _emailService.SendEmailAsync(emailSend);
    //}

}
}


    

