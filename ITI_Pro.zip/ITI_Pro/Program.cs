using ITI_Pro.Models;
using ITI_Pro.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<ITIPRDbContext>(
    op => op.UseSqlServer(builder.Configuration.GetConnectionString("myConn")));

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "go learn API", Version = "v1" });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme."
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        new string[] {}
                    }
                });
});

builder.Services.AddIdentityCore<ApplicationUser>(options =>
{
    options.Password.RequiredLength = 6;
    options.Password.RequireDigit = false;
    options.Password.RequireLowercase = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireNonAlphanumeric = false;

    options.SignIn.RequireConfirmedEmail = true;

}).AddRoles<IdentityRole>()
.AddRoleManager<RoleManager<IdentityRole>>()
.AddEntityFrameworkStores<ITIPRDbContext>()
.AddSignInManager<SignInManager<ApplicationUser>>()
.AddUserManager<UserManager<ApplicationUser>>()
.AddDefaultTokenProviders();

builder.Services.AddAuthorization(option =>
{
    option.AddPolicy("AdminPolicy", policy => policy.RequireRole("Admin"));
    option.AddPolicy("AdminPolicy", policy => policy.RequireRole("Instructor"));
    option.AddPolicy("AdminPolicy", policy => policy.RequireRole("Student"));
});
builder.Services.AddCors(op=>{
    op.AddPolicy("MyPolicy", policy => { policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader().WithOrigins("http://localhost:4200/"); });

});



builder.Services.AddAuthentication(op =>
{

    op.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    op.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    op.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;


}).AddJwtBearer(options => //verfied Key
 {
     options.SaveToken = true;
     options.RequireHttpsMetadata = false;
     options.TokenValidationParameters = new TokenValidationParameters()
     {
      //    "SecurityKey": "asdasdasdasdsads!@#@123adsa123125asd465@#@#@#@#@!!!!!",
      //"AudienceUrl": 

       ValidateIssuer = true,
         ValidIssuer = "https://localhost:7030/",
         ValidateAudience = true,
         ValidAudience = "http://localhost:4200/",
         IssuerSigningKey =
             new SymmetricSecurityKey(Encoding.UTF8.GetBytes("asdasdasdasdsads!@#@123adsa123125asd465@#@#@#@#@!!!!!"))


         //ValidateIssuer = true,
         //ValidIssuer = builder.Configuration["JWT:IssuerUrl"],
         //ValidateAudience = true,
         //ValidAudience = builder.Configuration["JWT:AudienceUrl"],
         //IssuerSigningKey =
         //    new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:SecurityKey"]))

     };

 });

//builder.Services.AddScoped<EmailService>();

//builder.Services.AddScoped<IServicesBase<Students>, StudentsServices>();
//builder.Services.AddScoped<IServicesBase<Specializations>, InstructorServices>();
builder.Services.AddScoped<IServicesBase<Course>, CourseServices>();

//builder.Services.AddScoped<IServicesBase<Enrollment>, EnrollmentServices>();
builder.Services.AddScoped<IServicesBase<Lesson>, LessonServices>();
builder.Services.AddScoped<IServicesBase<Content>, Contentservices>();



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
 
app.UseHttpsRedirection();

app.UseCors(policy=>policy.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());

app.UseAuthentication();
app.UseAuthorization();
app.UseStaticFiles();
app.MapControllers();

app.Run();
