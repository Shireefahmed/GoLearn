﻿namespace ITI_Pro.Models
{
    public class UserRole
    {
        public string UserName { get; set; } = string.Empty;
        public string role { get; set; } = string.Empty;
    }
}
