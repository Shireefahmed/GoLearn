﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

//namespace ITI_Pro.Models
//{
    //public class Instructor
    //{
        //[Key]

        //public int I_ID { get; set; }
        //public string I_FName { get; set; }

        //public string I_LName { get; set; }
        //public string I_Image { get; set; }
        //public string City { get; set; }
        //public string Spectialization { get; set; }
        //public Gender Gender { get; set; }
        //public string? PhoneNumber { get; set; }
        //[JsonIgnore]
        //public List<Course>? courses { get; set; }

        //[ForeignKey("User")]
        //public string UserId { get; set; }
//        //public virtual ApplictionUser? User { get; set; }
//    }
//    //public enum Gender { Male,Female }
//}
