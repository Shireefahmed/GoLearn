﻿using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ITI_Pro.Models
{
    public class Content
    {
        [Key]
        public int Content_Id { get; set; }
        public string VideoPath { get; set; }
        public string FilePath { get; set; }
        public string Title { get; set; }
        public string ContentType { get; set; }
        public string ImagePath { get; set; }
        //[ForeignKey("Lessons")]
        //public int L_Id { get; set; }
        
        [ForeignKey("Lessons")]
        public int? LessID { get; set; }
        [JsonIgnore]
        public Lesson? Lessons { get; set; }
    }
}
