﻿using Microsoft.AspNetCore.Identity;
using System.Text.Json.Serialization;

namespace ITI_Pro.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }

        public string? Role { get; set; }

        public string? I_Image { get; set; }
        public string? City { get; set; }
        
        public Gender Gender { get; set; }
        
        public string? PhoneNumber { get; set; }
        [JsonIgnore]
        public List<UserCourses>? UserCourses { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? Specialization  { get; set; }
        // public int? Experience { get; set; }

        //[JsonIgnore]
        //public List<Lesson>? lessons { get; set; }
    }
    public enum Gender { Male , Female}
        //public int ID_Std { get; set; }
        //public virtual Students? Students { get; set; }
        ////public int ID_Instruct { get; set; }
        //public virtual Instructor? Instructor { get; set; }

}
