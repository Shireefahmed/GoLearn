﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ITI_Pro.Models
{
    public class Course
    {
        [Key]

        public int Course_Id { get; set; }
        public string C_Description { get; set; }
        public string C_Title { get; set; }
        public string? ImageUrl { get; set; }


        //[ForeignKey("User")]
        //public string UserId { get; set; }
        [JsonIgnore]
        public List<UserCourses>? UserCourses { get; set; }

        [JsonIgnore]
        public ICollection<Lesson>? Lessons { get; set; }
        //public List<CRSLESSON>? cRSLESSONs { get; set; }


    }
}
