﻿using Microsoft.AspNetCore.Identity;

//namespace ITI_Pro.Models
//{
//    public class ApplictionUser:IdentityUser
//    {
//        public string FirstName { get; set; }
//        public string LastName { get; set; }

//        public string Role { get; set; }
//        //public int ID_Std { get; set; }
//        //public virtual Students? Students { get; set; }
//        ////public int ID_Instruct { get; set; }
//        //public virtual Instructor? Instructor { get; set; }

//    }
//}
