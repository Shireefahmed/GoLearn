﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

//namespace ITI_Pro.Models
//{
//    public class Students
//    {
//        //[Key]

//        //public int S_ID { get; set; }
//        //public string S_FName { get; set; }

//        //public string S_LName { get; set; }
//        //public string? S_Image { get; set; }
//        //public string? City { get; set; }
//        //public string? PhoneNumber { get; set; }
//        //public Gender Gender { get; set; }

//      //  [JsonIgnore]
//      //  public List<STDCourse>?sTDCourses { get; set; }
//        //public List<Lesson>? Lessons { get; set; }

//        //[ForeignKey("User")]
//        //public string UserId { get; set; }
//        //public virtual ApplictionUser? User { get; set; }
//    }
//    //public enum Gender { Male, Female }
//}
