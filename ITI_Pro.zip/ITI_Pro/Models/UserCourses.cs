﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ITI_Pro.Models
{
    public class UserCourses
    {
        [ForeignKey("User")]
        public string UserId { get; set; }
        public ApplicationUser User { get; set; }

        //public ICollection<ApplicationUser> User { get; set; }
        [ForeignKey("Course")]

        public int CourseId { get; set; }
        public Course Course { get; set; }

        //public ICollection<Course>  Course { get; set; }
        public DateTime DateTime { get; set; } = DateTime.Now;


    }
}
