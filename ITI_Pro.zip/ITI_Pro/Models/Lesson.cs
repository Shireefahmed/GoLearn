﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ITI_Pro.Models
{
    public class Lesson
    {
        [Key]

        public int L_Id { get; set; }
        public string? L_Description { get; set; }
        public string? L_Title { get; set; }

    
        public int CourseID { get; set; }
        [JsonIgnore]

        public  Course? Courses { get; set; }



        [JsonIgnore]
        public  Content? Content { get; set; }


        //[ForeignKey("User")]
        //public string UserId { get; set; }
        //public ApplicationUser? User { get; set; }

        //public  List<CRSLESSON>? cRSLESSONs { get; set; }
        //public List<Students>? students { get; set; }

    }
}
