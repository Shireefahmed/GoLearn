﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

//namespace ITI_Pro.Models.configurations
//{
//    public class InstructorConfigurations : IEntityTypeConfiguration<Instructor>
//    {
//        public void Configure(EntityTypeBuilder<Instructor> builder)
//        {
//       //     builder.HasMany(i => i.courses).WithOne(i => i.Instructor);
//            //builder.HasOne(o => o.User).WithOne(u => u.Instructor);

////            builder
////.HasOne(s => s.User);     // One student has one IdentityUser

//            //builder.HasData(
//            //    new Instructor() {I_ID = 1, I_FName = "Ahmed", I_LName = "Sale7", I_Image = "./././/./.", Gender = "Male"  },
//            //    new Instructor() { I_ID = 2,I_FName = "Sara", I_LName = "Ahmed", I_Image = "./././/./.", Gender = "Female" }
//            //    );
//        }
//    }
//}
