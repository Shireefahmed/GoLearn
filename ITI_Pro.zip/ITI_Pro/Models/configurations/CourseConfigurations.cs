﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ITI_Pro.Models.configurations
{
    public class CourseConfigurations : IEntityTypeConfiguration<Course>
    {

        public void Configure(EntityTypeBuilder<Course> builder)
        {
            builder.HasKey(t => new { t.Course_Id });

           
            builder.HasMany(t => t.Lessons).WithOne(o => o.Courses);
            //builder.HasData(
            //    new Course() { C_Description = "Hello", C_Title = "HelloW", I_ID = 1, Course_Id = 1 },
            //    new Course() { C_Description = "HelloS", C_Title = "HelloWOO", I_ID = 2, Course_Id = 2 }
            //    );
        }
    }
}
