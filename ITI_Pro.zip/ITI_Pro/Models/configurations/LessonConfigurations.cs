﻿using Microsoft.EntityFrameworkCore;
using ITI_Pro.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace ITI_Pro.Models.configurations
{
    public class LessonConfigurations : IEntityTypeConfiguration<Lesson>
    {
        public void Configure(EntityTypeBuilder<Lesson> builder)
        {

            builder.HasKey(t => new { t.L_Id });

            builder.HasOne(t => t.Courses)
                .WithMany(t => t.Lessons).HasForeignKey(p=>p.CourseID);

            builder.HasOne(t => t.Content)
                .WithOne(t => t.Lessons);
                 
            //builder.HasData(
            //    new Lesson() { L_Id = 1, L_Title = "Hello", L_Content = "Hello", CourseID = 1, ContID = 1 },
            //    new Lesson() { L_Id = 2, L_Title = "HelloW", L_Content = "HelloW", CourseID = 2, ContID = 2 }
            //    );

        }
    }
}
