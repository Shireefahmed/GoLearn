﻿using ITI_Pro.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Reflection.Emit;

//namespace ITI_Pro.Models.configurations
//{
//    public class StudentConfigurations : IEntityTypeConfiguration<Students>
//    {
//        public void Configure(EntityTypeBuilder<Students> builder)
//        {
//        //    builder.HasKey(s => s.S_ID);
//            //   builder.HasOne(s => s.User).WithOne(i => i.Students);


//       //     builder
//       //.HasOne(s => s.User);    // One student has one IdentityUser
 
//            //    builder.HasData(
//            //        new Students() { S_ID = 1, S_FName = "Ahmed", S_LName = "Mohsen", S_Image = ".//..//./", Gender = "Male"},
//            //        new Students() { S_ID = 2, S_FName = "Mohammed", S_LName = "Kamal", S_Image = ".//..//./", Gender = "Male" });
//            //}
//        }
//    }
//}
