﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ITI_Pro.Models.configurations
{
    public class ContentConfigurations : IEntityTypeConfiguration<Content>
    {
        public void Configure(EntityTypeBuilder<Content> builder)
        {
            builder.HasKey(c => c.Content_Id);
            //builder.Property<Content>(c=>c.
            builder.HasOne(c => c.Lessons).WithOne(c => c.Content);
            //builder.HasData(
            //    new Content() { Content_Id = 1, ContentType = "Monster", FilePath = "../././/.", ImagePath = ".././/././", Title = "SD" },
            //    new Content() { Content_Id = 2, ContentType = "Monster", FilePath = "../././/.", ImagePath = ".././/././", Title = "SD" }
            //    );
        }
    }
}
