﻿using Microsoft.EntityFrameworkCore;
using ITI_Pro.Models;

namespace ITI_Pro.Models.configurations
{
    public class StdCourseConfigurations : IEntityTypeConfiguration<UserCourses>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<UserCourses> builder)
        {
            builder.HasKey(t => new { t.CourseId, t.UserId });
            //builder.HasKey(t => new
            //{
            //    t.Crs_ID,
            //    t.Std_ID
            //});

            //builder.Property(p => p.DateTime).HasDefaultValue(DateTime.Now);
            //builder.HasOne(t => t.Students)
            //      .WithMany(t => t.sTDCourses)
            //      .HasForeignKey(t => t.Std_ID);
            //builder.HasOne(t => t.Course)
            //            .WithMany(t => t.sTDCourses)
            //            .HasForeignKey(t => t.Crs_ID);

        }
    }
}
