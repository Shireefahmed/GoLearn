﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Reflection;
using System.Reflection.Emit;

namespace ITI_Pro.Models
{
    //   public class ITIPRDbContext
    public class ITIPRDbContext : IdentityDbContext<ApplicationUser>
    {
        public ITIPRDbContext(DbContextOptions<ITIPRDbContext> option) : base(option) { }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            //seedRoles(builder);
            builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
            //builder.Entity<StdLesson>().HasKey(t => new {
            //    t.Std_ID,
            //    t.Lesson_ID
            //});

            //builder.Entity<StdLesson>().HasOne(t => t.Students)
            //    .WithMany(t => t.StdLessons)
            //    .HasForeignKey(t => t.Std_ID);
            //builder.Entity<StdLesson>().HasOne(t => t.Lesson)
            //           .WithMany(t => t.StdLessons)
            //           .HasForeignKey(t => t.Lesson_ID);


        }
        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{

        //    //  


        //    modelBuilder.Entity<StdCourse>().HasKey(t => new { t.Std_ID, t.Course_ID });

        //    modelBuilder.Entity<StdCourse>().HasOne(t => t.Students)
        //        .WithMany(t => t.stdCourses)
        //        .HasForeignKey(t => t.Std_ID);
        //    modelBuilder.Entity<StdCourse>().HasOne(t => t.Course)
        //       .WithMany(t => t.stdCourses)
        //       .HasForeignKey(t => t.Course_ID);


        //    modelBuilder.Entity<StdLesson>().HasKey(t => new { t.Std_ID, t.Lesson_ID
        //});

        //        modelBuilder.Entity<StdLesson>().HasOne(t => t.Students)
        //            .WithMany(t => t.StdLessons)
        //            .HasForeignKey(t => t.Std_ID);
        //modelBuilder.Entity<StdLesson>().HasOne(t => t.Lesson)
        //           .WithMany(t => t.StdLessons)
        //           .HasForeignKey(t => t.Lesson_ID);




        //modelBuilder.Entity<Lesson>().HasKey(t => new { t.L_Id });

        //modelBuilder.Entity<Lesson>().HasOne(t => t.Course)
        //    .WithMany(t => t.Lessons)
        //     .HasForeignKey(t => t.Course_ID);



        //modelBuilder.Entity<Lesson>().HasOne(t => t.Content)
        //    .WithMany(t => t.Lessons)
        //     .HasForeignKey(t => t.Content_ID);

        ////    modelBuilder.Entity<Enrollment>().HasOne(t=>t.En_Id).WithOwnsOne(t=>)

        //modelBuilder.Entity<Course>().HasKey(t => new { t.Course_Id });

        //modelBuilder.Entity<Course>().HasOne(t => t.Instructor)
        //    .WithMany(t => t.courses)
        //   .HasForeignKey(t => t.I_ID);




        //       modelBuilder.Entity<IdentityUserLogin<string>>()

        //.HasKey(ul => new { ul.UserId, ul.LoginProvider, ul.ProviderKey });



        //modelBuilder.Entity<IdentityUserRole<string>>().HasNoKey();
        //modelBuilder.Entity<IdentityUserLogin<string>>().HasNoKey();
        //modelBuilder.Entity<IdentityUserToken<string>>().HasNoKey();

        //  }


        //private static void seedRoles(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<IdentityRole>().HasData(
        //        new IdentityRole() { Name = "Admin", ConcurrencyStamp = "1", NormalizedName = "Admin" },
        //        new IdentityRole() { Name = "Instructor", ConcurrencyStamp = "2", NormalizedName = "Instructor" },
        //        new IdentityRole() { Name = "Student", ConcurrencyStamp = "3", NormalizedName = "Student" }
        //        );
        //}
        //public DbSet<Students> Students { get; set; }

        public DbSet<Course> Courses { get; set; }
      //  public DbSet<ApplicationUser> AppUsers { get; set; }

        public DbSet<Lesson> Lessons { get; set; }
        public DbSet<Content> Contents { get; set; }
       public  DbSet<UserCourses> UserCourses { get; set; }
    





    } 
}
