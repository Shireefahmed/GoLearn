﻿namespace ITI_Pro.Models
{
    //public class STDCourse
    //{
    //    public int Std_ID { get; set; }
    //    public virtual Students? Students { get; set; }
    //    public int Crs_ID { get; set; }
    //    public virtual Course? Course { get; set; }
    //    public DateTime DateTime { get; set; } = DateTime.Now;


    //}
}
