﻿namespace ITI_Pro.Helpers
{
    public class DocumentSettings
    {

        public static string UploadImages(IFormFile file)
        {
            var ex = Path.GetExtension(file.FileName);
            var filename = $"{file.FileName}_{Guid.NewGuid()}{ex}";
            var folderpath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Files/Images", filename);
            var filepath = Path.Combine(folderpath, filename);
            using (var filest = new FileStream(folderpath, FileMode.Create))
            {
                file.CopyTo(filest);
            }
            return "Files/Images/" + filename;
        }


        public static string UploadVideos(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                throw new ArgumentException("No file uploaded.");
            }

            var ex = Path.GetExtension(file.FileName);
            var filename = $"{Guid.NewGuid()}{ex}";
            var folderpath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Files", "Videos");

            // Ensure the directory exists
            if (!Directory.Exists(folderpath))
            {
                Directory.CreateDirectory(folderpath);
            }

            var filepath = Path.Combine(folderpath, filename);

            using (var filest = new FileStream(filepath, FileMode.Create))
            {
                file.CopyTo(filest);
            }

            return "Files/Videos/" + filename;
        }




        public static string UploadFiles(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                throw new ArgumentException("No file uploaded.");
            }

            var ex = Path.GetExtension(file.FileName);
            var filename = $"{Guid.NewGuid()}{ex}";
            var folderpath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Files", "AllFiles");

            if (!Directory.Exists(folderpath))
            {
                Directory.CreateDirectory(folderpath);
            }

            var filepath = Path.Combine(folderpath, filename);

            using (var fileStream = new FileStream(filepath, FileMode.Create))
            {
                file.CopyTo(fileStream);
            }

            return $"Files/AllFiles/{filename}";
        }

//        <form method = "post" enctype="multipart/form-data" action="/api/files/upload">
//    <input type = "file" name="file" />
//    <button type = "submit" > Upload File</button>
//</form>

    
    }
}


