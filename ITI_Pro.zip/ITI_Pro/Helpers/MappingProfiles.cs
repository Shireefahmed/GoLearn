﻿using AutoMapper;
using ITI_Pro.Models;
using ITI_Pro.ViewModels;
namespace ITI_Pro.Helpers
{
    public class MappingProfiles : Profile
    {
        public MappingProfiles() 
        {
            //CreateMap<Instructor, InstructorDto>().ForAllMembers(d=>d.);
            //CreateMap<Students, StudentDto>()
            //    .ForMember(d => d.Courses, s => s.MapFrom(d => d.Courses.Count()))
            //    .ForMember(d => d.Lessons, o => o.MapFrom(d => d.Lessons.Count()))
            //    .ForMember(d => d.Enrollments, o => o.MapFrom(d => d.Enrollments.En_Id));
                
        }
    }
}
